
package com.garytokman.g_tokman_lab1;

/*  Gary Tokman
    JAV1 - MDV3810*/

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.garytokman.g_tokman_lab1.model.Calculator;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";
    private TextView mInputText;
    private Button[] mButtons = new Button[16];
    private Calculator mCalculator = new Calculator();
    private String mFirst = "";
    private String mSecond = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set button ids
        for (int button = 0; button < mButtons.length; button++) {

            // Create id
            String buttonId = "button_" + button;
            // Get resource id
            int resourceId = getResources().getIdentifier(buttonId, "id", "com.garytokman.g_tokman_lab1");

            // Set id and listener on each button
            mButtons[button] = (Button) findViewById(resourceId);
            mButtons[button].setOnClickListener(this);
        }

        mInputText = (TextView) findViewById(R.id.input_textView);
    }

    // Override Onclick and check the id for each button
    @Override
    public void onClick(View view) {
        // Check view.getId against UI ids
        switch (view.getId()) {
            case R.id.button_0:


                if (mCalculator.getOperator() == null) {
                    // First number
                    mFirst += 0 + "";
                    mInputText.setText(mFirst);
                    mCalculator.setFirstInt(Integer.parseInt(mFirst));
                } else {
                    // Second number
                    mSecond += 0 + "";
                    mInputText.setText(mSecond);
                    mCalculator.setSecondInt(Integer.parseInt(mSecond));
                }


                break;
            case R.id.button_1:

                if (mCalculator.getOperator() == null) {
                    // First number
                    mFirst += 1 + "";
                    mInputText.setText(mFirst);
                    mCalculator.setFirstInt(Integer.parseInt(mFirst));
                } else {
                    // Second number
                    mSecond += 1 + "";
                    mInputText.setText(mSecond);
                    mCalculator.setSecondInt(Integer.parseInt(mSecond));
                }

                break;
            case R.id.button_2:

                if (mCalculator.getOperator() == null) {
                    // First number
                    mFirst += 2 + "";
                    mInputText.setText(mFirst);
                    mCalculator.setFirstInt(Integer.parseInt(mFirst));
                } else {
                    // Second number
                    mSecond += 2 + "";
                    mInputText.setText(mSecond);
                    mCalculator.setSecondInt(Integer.parseInt(mSecond));
                }

                break;
            case R.id.button_3:

                if (mCalculator.getOperator() == null) {
                    // First number
                    mFirst += 3 + "";
                    mInputText.setText(mFirst);
                    mCalculator.setFirstInt(Integer.parseInt(mFirst));
                } else {
                    // Second number
                    mSecond += 3 + "";
                    mInputText.setText(mSecond);
                    mCalculator.setSecondInt(Integer.parseInt(mSecond));
                }

                break;
            case R.id.button_4:

                if (mCalculator.getOperator() == null) {
                    // First number
                    mFirst += 4 + "";
                    mInputText.setText(mFirst);
                    mCalculator.setFirstInt(Integer.parseInt(mFirst));
                } else {
                    // Second number
                    mSecond += 4 + "";
                    mInputText.setText(mSecond);
                    mCalculator.setSecondInt(Integer.parseInt(mSecond));
                }

                break;
            case R.id.button_5:

                if (mCalculator.getOperator() == null) {
                    // First number
                    mFirst += 5 + "";
                    mInputText.setText(mFirst);
                    mCalculator.setFirstInt(Integer.parseInt(mFirst));
                } else {
                    // Second number
                    mSecond += 5 + "";
                    mInputText.setText(mSecond);
                    mCalculator.setSecondInt(Integer.parseInt(mSecond));
                }

                break;
            case R.id.button_6:
                if (mCalculator.getOperator() == null) {
                    // First number
                    mFirst += 6 + "";
                    mInputText.setText(mFirst);
                    mCalculator.setFirstInt(Integer.parseInt(mFirst));
                } else {
                    // Second number
                    mSecond += 6 + "";
                    mInputText.setText(mSecond);
                    mCalculator.setSecondInt(Integer.parseInt(mSecond));
                }


                break;
            case R.id.button_7:

                if (mCalculator.getOperator() == null) {
                    // First number
                    mFirst += 7 + "";
                    mInputText.setText(mFirst);
                    mCalculator.setFirstInt(Integer.parseInt(mFirst));
                } else {
                    // Second number
                    mSecond += 7 + "";
                    mInputText.setText(mSecond);
                    mCalculator.setSecondInt(Integer.parseInt(mSecond));
                }

                break;
            case R.id.button_8:

                if (mCalculator.getOperator() == null) {
                    // First number
                    mFirst += 8 + "";
                    mInputText.setText(mFirst);
                    mCalculator.setFirstInt(Integer.parseInt(mFirst));
                } else {
                    // Second number
                    mSecond += 8 + "";
                    mInputText.setText(mSecond);
                    mCalculator.setSecondInt(Integer.parseInt(mSecond));
                }

                break;
            case R.id.button_9:

                if (mCalculator.getOperator() == null) {
                    // First number
                    mFirst += 9 + "";
                    mInputText.setText(mFirst);
                    mCalculator.setFirstInt(Integer.parseInt(mFirst));
                } else {
                    // Second number
                    mSecond += 9 + "";
                    mInputText.setText(mSecond);
                    mCalculator.setSecondInt(Integer.parseInt(mSecond));
                }

                break;
            case R.id.button_10:
                // Clear
                mCalculator.setOperator("C");
                mFirst = "";
                mSecond = "";
                mCalculator.setOperator(null);
                mCalculator.setTotal();
                mInputText.setText(String.valueOf(mCalculator.getTotal()));

                break;
            case R.id.button_11:
                // Equals
                mCalculator.setOperator("=");
                mInputText.setText(String.valueOf(mCalculator.getTotal()));
                break;
            case R.id.button_12:
                // Add
                mCalculator.setOperator("+");
                break;
            case R.id.button_13:
                // Subtract
                mCalculator.setOperator("-");
                break;
            case R.id.button_14:
                // Multiply
                mCalculator.setOperator("*");
                break;
            case R.id.button_15:
                // Divide
                mCalculator.setOperator("/");
                break;
            default:
                Log.e(TAG, "Button not pressed");
        }

        if (mCalculator.getFirstInt() != 0 && mCalculator.getSecondInt() != 0) {
            mCalculator.setTotal();
            mFirst = "";
            mSecond = "";
        }


    }

}
