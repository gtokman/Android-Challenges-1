package com.garytokman.g_tokman_lab1.model;

import android.util.Log;

/**
 * Gary Tokman
 * JAV1 - MDV3810
 */
public class Calculator {

    private int mTotal;
    private int mFirstInt;
    private int mSecondInt;
    private String mOperator;

    public Calculator() {
        mTotal = 0;
        mFirstInt = 0;
        mSecondInt = 0;
        mOperator = null;
    }

    // Operator
    public String getOperator() {
        return mOperator;
    }

    public void setOperator(String operator) {
        mOperator = operator;
    }

    // Total
    public int getTotal() {
        return mTotal;
    }

    public void setTotal() {

        if (this.getOperator() != null) {

            if (this.getTotal() == 0) {
                switch (this.getOperator()) {
                    case "+":
                        mTotal = this.getFirstInt() + this.getSecondInt();
                        break;
                    case "-":
                        mTotal = this.getFirstInt() - this.getSecondInt();
                        break;
                    case "*":
                        mTotal = this.getFirstInt() * this.getSecondInt();
                        break;
                    case "/":
                        mTotal = this.getFirstInt() / this.getSecondInt();
                    case "=":
                        this.getTotal();
                        break;
                    default:
                        // Clear total
                        this.setFirstInt(0);
                        this.setSecondInt(0);
                        mTotal = 0;
                }
            } else {

                switch (this.getOperator()) {
                    case "+":
                        mTotal += this.getSecondInt();
                        break;
                    case "-":
                        mTotal += this.getSecondInt();
                        break;
                    case "*":
                        mTotal += this.getSecondInt();
                        break;
                    case "/":
                        mTotal += this.getSecondInt();
                        break;
                    case "=":
                        this.getTotal();
                        break;
                    default:
                        // Clear total
                        this.setFirstInt(0);
                        this.setSecondInt(0);
                        mTotal = 0;
                }

            }

        } else {
            // Clear
            this.setFirstInt(0);
            this.setSecondInt(0);
            mTotal = 0;
        }

    }

    // Temp Integers
    public int getFirstInt() {
        return mFirstInt;
    }

    public void setFirstInt(int firstInt) {
        mFirstInt = firstInt;
    }

    public int getSecondInt() {
        return mSecondInt;
    }

    public void setSecondInt(int secondInt) {
        mSecondInt = secondInt;
    }
}
